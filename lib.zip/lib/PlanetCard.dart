class PlanetCard {
  String cardTitle = "";
  String cardImage = "";
  double topMargin = 0.0;

  PlanetCard(String title, String imagePath, double marginTop) {
    cardTitle = title;
    cardImage = imagePath;
    topMargin = marginTop;
  }
}
